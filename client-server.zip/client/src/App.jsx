import Display from "./components/Display";
import InputForm from "./components/InputForm";

function App() {
  return (
    <>
    <InputForm/>
    <Display />
    </>
  );
}

export default App;
